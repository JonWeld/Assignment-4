import javax.swing.*;
import java.awt.*;

public class ATMFrame extends JFrame {

    // Components of the ATM interface
    private JLabel cardLabel;
    private JTextField cardTextField;
    private JLabel pinLabel;
    private JPasswordField pinTextField;
    private JButton withdrawButton;
    private JButton depositButton;
    private JButton transferButton;
    private JButton balanceButton;
    private JButton cancelButton;

    public ATMFrame() {
        // Set up the JFrame properties
        setTitle("ATM Machine");
        setSize(400, 300);
        setLocationRelativeTo(null); // center the JFrame on the screen
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Create the components of the ATM interface
        cardLabel = new JLabel("Enter card number:");
        cardTextField = new JTextField(20);
        pinLabel = new JLabel("Enter PIN:");
        pinTextField = new JPasswordField(20);
        withdrawButton = new JButton("Withdraw");
        depositButton = new JButton("Deposit");
        transferButton = new JButton("Transfer");
        balanceButton = new JButton("Check balance");
        cancelButton = new JButton("Cancel");

        // Add the components to the JFrame using a GridBagLayout
        setLayout(new GridBagLayout());
        GridBagConstraints gc = new GridBagConstraints();
        gc.gridx = 0;
        gc.gridy = 0;
        gc.anchor = GridBagConstraints.WEST;
        gc.insets = new Insets(10, 10, 10, 10); // add some padding
        add(cardLabel, gc);

        gc.gridx = 1;
        gc.gridy = 0;
        add(cardTextField, gc);

        gc.gridx = 0;
        gc.gridy = 1;
        add(pinLabel, gc);

        gc.gridx = 1;
        gc.gridy = 1;
        add(pinTextField, gc);

        gc.gridx = 0;
        gc.gridy = 2;
        add(withdrawButton, gc);

        gc.gridx = 1;
        gc.gridy = 2;
        add(depositButton, gc);

        gc.gridx = 0;
        gc.gridy = 3;
        add(transferButton, gc);

        gc.gridx = 1;
        gc.gridy = 3;
        add(balanceButton, gc);

        gc.gridx = 0;
        gc.gridy = 4;
        add(cancelButton, gc);

        // Make the JFrame visible
        setVisible(true);
    }

    // Test the ATMFrame class
    public static void main(String[] args) {
        new ATMFrame();
    }
}
